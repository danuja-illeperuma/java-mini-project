import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateProfile extends JFrame{
    private JLabel firstName;
    private JLabel lastName;
    private JPanel profile;
    private JButton updateButton;
    private JTextField email;
    private JTextField pnumber;
    private JTextField photo;
    private JTextField uname;
    private JLabel user;
    private JTextField name1;
    private JTextField name2;
    private JButton resetButton;

    public JPanel getProfile() {
        return profile;
    }

    public  UpdateProfile() {

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String emailText = email.getText().trim();
                    String pnumberText = pnumber.getText().trim();

                    if (!isValidEmail(emailText)) {
                        JOptionPane.showMessageDialog(null, "Invalid email address");
                        return;
                    }
                    if (pnumberText.length() != 11) {
                        JOptionPane.showMessageDialog(null, "Invalid phone number");
                        return;
                    }

                    Connection con = DatabaseConnection.getConnection();
                    String sql = "UPDATE users SET first_name=? , last_name=?,email=?, phone=?,profile_picture=? WHERE username=?";
                    PreparedStatement ps = con.prepareStatement(sql);

                    ps.setString(1, name1.getText());
                    ps.setString(2, name2.getText());
                    ps.setString(3, email.getText());
                    ps.setString(4, pnumber.getText());

                    File imageFile = new File(photo.getText()); // assumes full path in photo text field
                    if (!imageFile.exists()) {
                        JOptionPane.showMessageDialog(null, "Photo file not found");
                        return;
                    }

                    FileInputStream fis = new FileInputStream(imageFile);
                    ps.setBinaryStream(5, fis, (int) imageFile.length());

                    ps.setString(6, uname.getText().trim());

                    int rs = ps.executeUpdate();

                    if (rs > 0) {
                        JOptionPane.showMessageDialog(null, " Profile updated successfully");
                    } else {
                        JOptionPane.showMessageDialog(null, "Update Failed");
                    }
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                uname.setText("");
                name1.setText("");
                name2.setText("");
                email.setText("");
                pnumber.setText("");
                photo.setText("");

            }
        });
    }

        public boolean isValidEmail(String email) {
            String emailValidate = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
            return email.matches(emailValidate);
        }
        public boolean isValidPhone(String phone) {
        String phoneValidate = "^[0-9]{10}$";
        return phone.matches(phoneValidate);
        }
}

