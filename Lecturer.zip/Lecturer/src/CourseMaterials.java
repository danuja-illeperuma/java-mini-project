import javax.swing.*;

public class CourseMaterials {
    private JTextField textField1;
    private JButton uploadButton;
    private JTextField textField2;
    private JPanel courseMaterials;

    public JPanel getCourseMaterials() {
        return courseMaterials;
    }
}
