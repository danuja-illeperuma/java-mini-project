import javax.swing.*;

public class Eligibility {
    private JPanel eligibility;
    private JLabel studentId;
    private JLabel courseCode;
    private JButton submitButton;
    private JTextField eStatus;
    private JTextField stuid;
    private JTextField cCode;

    public JPanel getEligibility() {
        return eligibility;
    }
}
