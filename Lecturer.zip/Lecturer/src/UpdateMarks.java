import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;

public class UpdateMarks {
    private JTextField cCode;
    private JTextField stuId;
    private JTextField stuMarks;
    private JLabel marksTitle;
    private JLabel courceCode;
    private JLabel studentId;
    private JLabel examType;
    private JLabel marks;
    private JComboBox eType;
    private JPanel markPanel;
    private JButton submitButton;
    private JButton resetButton;

    public UpdateMarks() {
        cCode.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });


        stuId.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        eType.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        stuMarks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            };
        });
    }

    public JPanel getMarks() {
        return markPanel;
    }


}
