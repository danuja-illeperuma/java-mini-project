import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateProfile extends JFrame{
    private JTextField name;
    private JTextField pass;
    private JLabel userName;
    private JLabel password;
    private JPanel profile;
    private JButton updateButton;

    public JPanel getProfile() {
        return profile;
    }

    public  UpdateProfile() {

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(name.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter your name");

                }
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(pass.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter your password");
                }
            }
        });
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
}

