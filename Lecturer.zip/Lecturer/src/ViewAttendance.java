import javax.swing.*;

public class ViewAttendance {
    private JLabel studentId;
    private JLabel courceCode;
    private JTextField stu_id;
    private JTextField c_code;
    private JTextField att;
    private JButton submitbutton;
    private JLabel Attendance;
    private JPanel viewAttendance;

    public JPanel getViewAttendance() {
        return viewAttendance;
    }
}
