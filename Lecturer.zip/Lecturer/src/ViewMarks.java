import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ViewMarks extends JFrame {
    private JPanel viewMarks;
    private JTextField code;
    private JTextField result;
    private JComboBox comboBox1;
    private JLabel courseCode;
    private JTextField stu_id;
    private JTextField c_code;
    private JTextField stu_grade;
    private JTextField stu_sgpa;
    private JTextField stu_cgpa;
    private JButton submitButton;
    private JButton resetButton;
    private JButton Submit;
    private JComboBox comboBox2;
    private JButton Reset;
    private JPanel batch;
    private JPanel Individual;
    private JPanel marks;
    private JButton CGPAButton;
    private JButton gradeButton;
    private JButton SGPAButton;
    private JButton submitButton2;
    private JTextField stu_id2;

    public ViewMarks() {
        gradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Grade grade = new Grade();
                marks.setLayout(new BorderLayout());
                marks.removeAll();
                marks.add(grade.getGrade());
                marks.repaint();
                marks.revalidate();
            }
        });
        SGPAButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SGPA sgpa = new SGPA();
                marks.setLayout(new BorderLayout());
                marks.removeAll();
                marks.add(sgpa.getSgpa());
                marks.repaint();
                marks.revalidate();
            }
        });
        CGPAButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CGPA cgpa = new CGPA();
                marks.setLayout(new BorderLayout());
                marks.removeAll();
                marks.add(cgpa.getCgpa());
                marks.repaint();
                marks.revalidate();
            }
        });
    }

    public JPanel getViewMarks() {
        return viewMarks;
    }
}

