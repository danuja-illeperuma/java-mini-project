import javax.swing.*;

public class ViewMedical {
    private JLabel studentId;
    private JLabel courseCode;
    private JButton submitButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JPanel viewMedical;

    public JPanel getViewMedical() {
        return viewMedical;
    }
}
