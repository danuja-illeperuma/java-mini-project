/*import javax.swing.*;

public class Profile extends JFrame
{
    private JPanel profilePanel;
    private JButton changeProfilePictureButton;
    private JButton saveChangesButton;
    private JLabel image;
    private JTextField update_email;
    private JTextField update_contact;
    private JLabel u_details;
    private JLabel fname;
    private JLabel f_name;
    private JLabel lname;
    private JLabel l_name;
    private JLabel email;
    private JLabel mail;
    private JLabel contact;
    private JLabel num;
    private JLabel update_udetails;
    private JLabel email2;
    private JLabel c_num;
}
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.ImageIcon;

public class Profile extends JPanel {
    private JButton changeProfilePictureButton;
    private JButton saveChangesButton;
    private JLabel image;
    private JTextField update_email;
    private JTextField update_contact;
    private JLabel fname;
    private JLabel f_name;
    private JLabel lname;
    private JLabel l_name;
    private JLabel email;
    private JLabel contact;
    private JPanel profilePanel;
    private JLabel u_details;
    private JLabel update_udetails;
    private JLabel email2;
    private JLabel c_num;
    private JLabel mail;
    private JLabel num;

    private String userId;
    private String profilePicPath, firstName, lastName, emailVal, phone;
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;

    public Profile(String userId) {
        this.userId = userId;
        setLayout(null);
        setBackground(Color.WHITE);

        initComponents();
        getUserDetails();
    }



    private void initComponents() {
      //  image = new JLabel("profile");
       // image.setBounds(400, 20, 150, 150);
        image.setIcon(new ImageIcon(getClass().getClassLoader().getResource("dp.jpg")));
        // image.setBounds(400, 20, 150, 150);
       // image.setIcon(new javax.swing.ImageIcon(getClass().getResource("dp.png")));
        add(image);

        changeProfilePictureButton = new JButton("Change Profile Picture");
        changeProfilePictureButton.setBounds(400, 180, 160, 25);
        add(changeProfilePictureButton);

        fname = new JLabel("First Name:");
        fname.setBounds(30, 50, 100, 25);
        add(fname);

        f_name = new JLabel();
        f_name.setBounds(150, 50, 200, 25);
        add(f_name);

        lname = new JLabel("Last Name:");
        lname.setBounds(30, 90, 100, 25);
        add(lname);

        l_name = new JLabel();
        l_name.setBounds(150, 90, 200, 25);
        add(l_name);

        email = new JLabel("Email:");
        email.setBounds(30, 130, 100, 25);
        add(email);

        update_email = new JTextField();
        update_email.setBounds(150, 130, 200, 25);
        add(update_email);

        contact = new JLabel("Contact:");
        contact.setBounds(30, 170, 100, 25);
        add(contact);

        update_contact = new JTextField();
        update_contact.setBounds(150, 170, 200, 25);
        add(update_contact);

        saveChangesButton = new JButton("Save Changes");
        saveChangesButton.setBounds(150, 220, 200, 30);
        add(saveChangesButton);

        changeProfilePictureButton.addActionListener(e -> changeProfilePicture());
        saveChangesButton.addActionListener(e -> updateContactAndEmail());
    }

    private void getUserDetails() {
        try {
            con = dbconnection.getConnection();
            String query = "SELECT * FROM users WHERE user_id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                emailVal = rs.getString("user_email");
                phone = rs.getString("user_phone");
                profilePicPath = rs.getString("user_pro_pic");

                f_name.setText(firstName);
                l_name.setText(lastName);
                update_email.setText(emailVal);
                update_contact.setText(phone);

                if (profilePicPath != null && !profilePicPath.trim().isEmpty()) {
                    image.setIcon(new ImageIcon(new ImageIcon(profilePicPath).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH)));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void changeProfilePicture() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose a Profile Picture");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            String selectedPath = chooser.getSelectedFile().getAbsolutePath();
            updateProfilePicInDB(selectedPath);
            image.setIcon(new ImageIcon(new ImageIcon(selectedPath).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH)));
            JOptionPane.showMessageDialog(this, "Profile picture updated!");
        }
    }

    private void updateProfilePicInDB(String path) {
        try {
            con = dbconnection.getConnection();
            String update = "UPDATE user SET user_pro_pic = ? WHERE user_id = ?";
            ps = con.prepareStatement(update);
            ps.setString(1, path);
            ps.setString(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void updateContactAndEmail() {
        String newEmail = update_email.getText().trim();
        String newContact = update_contact.getText().trim();

        if (!newEmail.matches("^\\S+@\\S+\\.\\S+$") || !newContact.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Invalid email or contact number!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            con = dbconnection.getConnection();
            String update = "UPDATE user SET user_email = ?, user_phone = ? WHERE user_id = ?";
            ps = con.prepareStatement(update);
            ps.setString(1, newEmail);
            ps.setString(2, newContact);
            ps.setString(3, userId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Details updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void closeResources() {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public JPanel getProfile() {
        return profilePanel;
    }

}
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.border.Border;

public class Profile extends JPanel {
    private JButton changeProfilePictureButton;
    private JButton saveChangesButton;
    private JLabel image;
    private JTextField update_email;
    private JTextField update_contact;
    private JLabel fname;
    private JLabel f_name;
    private JLabel lname;
    private JLabel l_name;
    private JLabel email;
    private JLabel contact;
    private JPanel profilePanel;
    private JLabel u_details;
    private JLabel update_udetails;
    private JLabel email2;
    private JLabel c_num;
    private JLabel mail;
    private JLabel num;

    private String userId;
    private String profilePicPath, firstName, lastName, emailVal, phone;
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;

    public Profile(String userId) {
        this.userId = userId;
        setLayout(null);
        setBackground(Color.WHITE);

        initComponents();
        getUserDetails();
    }

    private void initComponents() {
        // Initialize image label with border
        image = new JLabel();
        image.setBounds(400, 20, 150, 150);
        Border border = BorderFactory.createLineBorder(new Color(100, 100, 100), 2, true);
        image.setBorder(border);
        image.setHorizontalAlignment(SwingConstants.CENTER);
        image.setVerticalAlignment(SwingConstants.CENTER);

        // Try to load default image
        try {
            ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource("dp.jpg"));
            if (icon != null) {
                Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                image.setIcon(new ImageIcon(img));
            } else {
                image.setText("No Image");
            }
        } catch (Exception e) {
            image.setText("No Image");
        }
        add(image);

        changeProfilePictureButton = new JButton("Change Profile Picture");
        changeProfilePictureButton.setBounds(400, 180, 160, 25);
        add(changeProfilePictureButton);

        fname = new JLabel("First Name:");
        fname.setBounds(30, 50, 100, 25);
        add(fname);

        f_name = new JLabel();
        f_name.setBounds(150, 50, 200, 25);
        add(f_name);

        lname = new JLabel("Last Name:");
        lname.setBounds(30, 90, 100, 25);
        add(lname);

        l_name = new JLabel();
        l_name.setBounds(150, 90, 200, 25);
        add(l_name);

        email = new JLabel("Email:");
        email.setBounds(30, 130, 100, 25);
        add(email);

        update_email = new JTextField();
        update_email.setBounds(150, 130, 200, 25);
        add(update_email);

        contact = new JLabel("Contact:");
        contact.setBounds(30, 170, 100, 25);
        add(contact);

        update_contact = new JTextField();
        update_contact.setBounds(150, 170, 200, 25);
        add(update_contact);

        saveChangesButton = new JButton("Save Changes");
        saveChangesButton.setBounds(150, 220, 200, 30);
        add(saveChangesButton);

        changeProfilePictureButton.addActionListener(e -> changeProfilePicture());
        saveChangesButton.addActionListener(e -> updateContactAndEmail());
    }

    private void getUserDetails() {
        try {
            con = dbconnection.getConnection();
            String query = "SELECT * FROM users WHERE user_id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                emailVal = rs.getString("user_email");
                phone = rs.getString("user_phone");
                profilePicPath = rs.getString("user_pro_pic");

                f_name.setText(firstName);
                l_name.setText(lastName);
                update_email.setText(emailVal);
                update_contact.setText(phone);

                if (profilePicPath != null && !profilePicPath.trim().isEmpty()) {
                    ImageIcon icon = new ImageIcon(profilePicPath);
                    Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                    image.setIcon(new ImageIcon(img));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void changeProfilePicture() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose a Profile Picture");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            String selectedPath = chooser.getSelectedFile().getAbsolutePath();
            updateProfilePicInDB(selectedPath);
            ImageIcon icon = new ImageIcon(selectedPath);
            Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            image.setIcon(new ImageIcon(img));
            JOptionPane.showMessageDialog(this, "Profile picture updated!");
        }
    }

    private void updateProfilePicInDB(String path) {
        try {
            con = dbconnection.getConnection();
            String update = "UPDATE user SET user_pro_pic = ? WHERE user_id = ?";
            ps = con.prepareStatement(update);
            ps.setString(1, path);
            ps.setString(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void updateContactAndEmail() {
        String newEmail = update_email.getText().trim();
        String newContact = update_contact.getText().trim();

        if (!newEmail.matches("^\\S+@\\S+\\.\\S+$") || !newContact.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Invalid email or contact number!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            con = dbconnection.getConnection();
            String update = "UPDATE user SET user_email = ?, user_phone = ? WHERE user_id = ?";
            ps = con.prepareStatement(update);
            ps.setString(1, newEmail);
            ps.setString(2, newContact);
            ps.setString(3, userId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Details updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private void closeResources() {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public JPanel getProfile() {
        return profilePanel;
    }
}
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.*;

public class Profile extends JFrame{
    private JPanel mainPanel;
    private JPanel profilePanel;
    private JButton changeProfilePictureButton;
    private JButton saveChangesButton;
    private JLabel image;
    private JTextField update_email;
    private JTextField update_contact;
    private JLabel u_details;
    private JLabel fname;
    private JLabel f_name;
    private JLabel lname;
    private JLabel l_name;
    private JLabel email;
    private JLabel mail;
    private JLabel contact;
    private JLabel num;
    private JLabel update_udetails;
    private JLabel email2;
    private JLabel c_num;

    private String studentUsername;
    private String firstName;
    private String lastName;

    public StudentProfile(String studentUsername, String firstName, String lastName) {
        this.studentUsername = studentUsername;
        this.firstName = firstName;
        this.lastName = lastName;

        JFrame frame = new JFrame("Student Profile");
        frame.setContentPane(mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1400, 750);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Load profile details when form opens
        loadProfileDetails();

        saveChangesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateProfile();
            }
        });

        changeProfilePictureButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changeProfilePicture();
            }
        });
    }

    private void loadProfileDetails() {
        // Get connection from DbConnection class
        Connection conn = dbconnection.getConnection();

        String sql = "SELECT * FROM student WHERE username = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, studentUsername);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Set personal details
                f_name.setText(firstName);
                l_name.setText(lastName);
                mail.setText(rs.getString("email"));
                num.setText(rs.getString("phone_number"));

                // Set profile picture if available
                String imagePath = rs.getString("profile_picture");
                if (imagePath != null && !imagePath.isEmpty()) {
                    ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage()
                            .getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH));
                    image.setIcon(icon);
                } else {
                    // You can set a default image here if needed
                    image.setIcon(null);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateProfile() {
        String newEmail = update_email.getText().trim();
        String newContact = update_contact.getText().trim();

        // Validate input
        if (newEmail.isEmpty() && newContact.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter new email or contact information");
            return;
        }

        Connection conn = dbconnection.getConnection();

        StringBuilder sqlBuilder = new StringBuilder("UPDATE student SET ");
        boolean needComma = false;

        if (!newEmail.isEmpty()) {
            sqlBuilder.append("email = ?");
            needComma = true;
        }

        if (!newContact.isEmpty()) {
            if (needComma) {
                sqlBuilder.append(", ");
            }
            sqlBuilder.append("phone_number = ?");
        }

        sqlBuilder.append(" WHERE username = ?");

        try (PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString())) {
            int paramIndex = 1;

            if (!newEmail.isEmpty()) {
                stmt.setString(paramIndex++, newEmail);
            }

            if (!newContact.isEmpty()) {
                stmt.setString(paramIndex++, newContact);
            }

            stmt.setString(paramIndex, studentUsername);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Profile updated successfully!");
                // Clear the input fields
                update_email.setText("");
                update_contact.setText("");
                // Reload profile to show updated information
                loadProfileDetails();
            } else {
                JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error updating profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void changeProfilePicture() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Profile Picture");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String imagePath = selectedFile.getAbsolutePath();

            // Update the profile picture path in the database
            Connection conn = dbconnection.getConnection();

            String sql = "UPDATE student SET profile_picture = ? WHERE username = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, imagePath);
                stmt.setString(2, studentUsername);

                int rowsUpdated = stmt.executeUpdate();

                if (rowsUpdated > 0) {
                    // Update the image in the UI
                    ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage()
                            .getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH));
                    image.setIcon(icon);

                    JOptionPane.showMessageDialog(null, "Profile picture updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update profile picture.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error updating profile picture: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentProfile("student123", "John", "Doe");
        });
    }
}*/
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.*;

public class UProfile extends JFrame {
    private JPanel mainPanel;
    private JPanel profilePanel;
    private JButton changeProfilePictureButton;
    private JButton saveChangesButton;
    private JLabel image;
    private JTextField update_email;
    private JTextField update_contact;
    private JLabel u_details;
    private JLabel fname;
    private JLabel f_name;
    private JLabel lname;
    private JLabel l_name;
    private JLabel email;
    private JLabel mail;
    private JLabel contact;
    private JLabel num;
    private JLabel update_udetails;
    private JLabel email2;
    private JLabel c_num;

    private String userId;

    public UProfile(String userId) throws SQLException {
        this.userId = userId;

        // Initialize the panel (not creating a new JFrame since we'll add this panel to another container)
        mainPanel = new JPanel();
        profilePanel = new JPanel();

        // Initialize UI components
        initComponents();

        // Set layout for panels
        setupLayout();

        // Load user profile data
        loadProfileDetails();

        // Add action listeners
        setupActionListeners();
    }

    private void initComponents() {
        // Initialize all UI components
        changeProfilePictureButton = new JButton("Change Profile Picture");
        saveChangesButton = new JButton("Save Changes");
        image = new JLabel();
        update_email = new JTextField(20);
        update_contact = new JTextField(20);
        u_details = new JLabel("User Details");
        fname = new JLabel("First Name:");
        f_name = new JLabel();
        lname = new JLabel("Last Name:");
        l_name = new JLabel();
        email = new JLabel("Email:");
        mail = new JLabel();
        contact = new JLabel("Contact:");
        num = new JLabel();
        update_udetails = new JLabel("Update User Details");
        email2 = new JLabel("Email:");
        c_num = new JLabel("Contact Number:");
    }

    private void setupLayout() {
        // Set up the layout for the panels
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        profilePanel.setLayout(null); // Using absolute positioning

        // Set positions and sizes for components
        image.setBounds(50, 50, 100, 100);

        u_details.setBounds(50, 170, 200, 25);
        fname.setBounds(50, 210, 100, 25);
        f_name.setBounds(160, 210, 200, 25);
        lname.setBounds(50, 250, 100, 25);
        l_name.setBounds(160, 250, 200, 25);
        email.setBounds(50, 290, 100, 25);
        mail.setBounds(160, 290, 200, 25);
        contact.setBounds(50, 330, 100, 25);
        num.setBounds(160, 330, 200, 25);

        update_udetails.setBounds(50, 380, 200, 25);
        email2.setBounds(50, 420, 100, 25);
        update_email.setBounds(160, 420, 200, 25);
        c_num.setBounds(50, 460, 120, 25);
        update_contact.setBounds(160, 460, 200, 25);

        changeProfilePictureButton.setBounds(50, 520, 180, 30);
        saveChangesButton.setBounds(250, 520, 120, 30);

        // Add components to profilePanel
        profilePanel.add(image);
        profilePanel.add(u_details);
        profilePanel.add(fname);
        profilePanel.add(f_name);
        profilePanel.add(lname);
        profilePanel.add(l_name);
        profilePanel.add(email);
        profilePanel.add(mail);
        profilePanel.add(contact);
        profilePanel.add(num);
        profilePanel.add(update_udetails);
        profilePanel.add(email2);
        profilePanel.add(update_email);
        profilePanel.add(c_num);
        profilePanel.add(update_contact);
        profilePanel.add(changeProfilePictureButton);
        profilePanel.add(saveChangesButton);

        // Add profilePanel to mainPanel
        mainPanel.add(profilePanel);
    }

    private void setupActionListeners() {
        saveChangesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateProfile();
            }
        });

        changeProfilePictureButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changeProfilePicture();
            }
        });
    }

    // This method returns the profile panel to be added to another container
    public JPanel getProfile() {
        return mainPanel;
    }

    private void loadProfileDetails() throws SQLException {
        // Get connection from dbconnection class
        Connection conn = dbconnection.getConnection();

        String sql = "SELECT * FROM users WHERE user_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Set personal details
                f_name.setText(rs.getString("first_name"));
                l_name.setText(rs.getString("last_name"));
                mail.setText(rs.getString("email"));
                num.setText(rs.getString("phone_number"));

                // Set profile picture if available
                String imagePath = rs.getString("profile_picture");
                if (imagePath != null && !imagePath.isEmpty()) {
                    ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage()
                            .getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH));
                    image.setIcon(icon);
                } else {
                    // You can set a default image here if needed
                    image.setIcon(null);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateProfile() {
        String newEmail = update_email.getText().trim();
        String newContact = update_contact.getText().trim();

        // Validate input
        if (newEmail.isEmpty() && newContact.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter new email or contact information");
            return;
        }

        Connection conn = null;
        try {
            conn = dbconnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        StringBuilder sqlBuilder = new StringBuilder("UPDATE student SET ");
        boolean needComma = false;

        if (!newEmail.isEmpty()) {
            sqlBuilder.append("email = ?");
            needComma = true;
        }

        if (!newContact.isEmpty()) {
            if (needComma) {
                sqlBuilder.append(", ");
            }
            sqlBuilder.append("phone = ?");
        }

        sqlBuilder.append(" WHERE user_id = ?");

        try (PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString())) {
            int paramIndex = 1;

            if (!newEmail.isEmpty()) {
                stmt.setString(paramIndex++, newEmail);
            }

            if (!newContact.isEmpty()) {
                stmt.setString(paramIndex++, newContact);
            }

            stmt.setString(paramIndex, userId);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Profile updated successfully!");
                // Clear the input fields
                update_email.setText("");
                update_contact.setText("");
                // Reload profile to show updated information
                loadProfileDetails();
            } else {
                JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error updating profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void changeProfilePicture() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Profile Picture");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String imagePath = selectedFile.getAbsolutePath();

            // Update the profile picture path in the database
            Connection conn = null;
            try {
                conn = dbconnection.getConnection();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            String sql = "UPDATE users SET profile_picture = ? WHERE user_id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, imagePath);
                stmt.setString(2, userId);

                int rowsUpdated = stmt.executeUpdate();

                if (rowsUpdated > 0) {
                    // Update the image in the UI
                    ImageIcon icon = new ImageIcon(new ImageIcon(imagePath).getImage()
                            .getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH));
                    image.setIcon(icon);

                    JOptionPane.showMessageDialog(null, "Profile picture updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update profile picture.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error updating profile picture: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
