import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddAttendance extends JFrame {
    private JPanel AddAttMain;
    private JTextField sid_tf,c_hourse_tf,lec_date_tf,at_status_tf,c_type_tf;
    private JButton ADDButton, UPDATEButton,DELETEButton,CLEARButton;
    private JLabel sid_l,c_code_l, c_hourse_L,lec_date_l,att_status_l,c_type_l;
    private JLabel header;
    private JPanel labelPanel;
    private JPanel valuePanel;
    private JComboBox<String> c_code_combo;
    private Connection conn;

    public AddAttendance() {
       setTitle("Add Attendance");
       setContentPane(AddAttMain);
       setSize(800, 600);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       getContentPane().setBackground(new Color(217,240,250));
       setLocationRelativeTo(null);

        databaseConnect();
        callCourseCode();
        getUserDetails();

        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst = conn.prepareStatement("INSERT INTO attendance_detail (username,c_code,c_hours,lec_date,at_state,c_type) values (?,?,?,?,?,?)");
                    pst.setString(1, sid_tf.getText() );
                    pst.setString(2, (String) c_code_combo.getSelectedItem() );
                    pst.setString(3, c_hourse_tf.getText() );
                    pst.setString(4, lec_date_tf.getText() );
                    pst.setString(5, at_status_tf.getText() );
                    pst.setString(6, c_type_tf.getText() );

                    JOptionPane.showMessageDialog(null, "Attendance Added Successfully");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Attendance Not Added Successfully");

                }
            }
        });


        UPDATEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst = conn.prepareStatement("UPDATE attendance_detail SET c_hours = ? ,at_state = ?  WHERE username = ? AND c_code = ? AND lec_date = ? AND c_type = ?");
                    pst.setString(1, c_hourse_tf.getText() );
                    pst.setString(2, at_status_tf.getText() );
                    pst.setString(3,sid_tf.getText() );
                    pst.setString(4, (String)c_code_combo.getSelectedItem() );
                    pst.setString(5,lec_date_tf.getText() );
                    pst.setString(6,c_type_tf.getText() );


                    int result = pst.executeUpdate();

                    if (result > 0) {
                        JOptionPane.showMessageDialog(null, "Attendance Updated Successfully");

                    }else{
                        JOptionPane.showMessageDialog(null, "No record found");
                    }

                }catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error Updating Attendance. Please try again");
                }
            }
        });

        CLEARButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    sid_tf.setText("");
                    c_code_combo.setSelectedIndex(0);
                    c_hourse_tf.setText("");
                    lec_date_tf.setText("");
                    at_status_tf.setText("");
                    c_type_tf.setText("");
            }
        });


        DELETEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst =  conn.prepareStatement("DELETE FROM attendance_detail WHERE username = ? ");
                    pst.setString(1, sid_tf.getText());
                    int delete = pst.executeUpdate();

                    if (delete > 0) {
                        JOptionPane.showMessageDialog(null, "Attendance Deleted Successfully");

                    }else{
                        JOptionPane.showMessageDialog(null, "No record found");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error Deleting Attendance. Please try again");
                }

            }
        });
        sid_tf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(sid_tf.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter the user name");
                }
            }
        });

    }

    private void callCourseCode() {
        try{
            PreparedStatement pst = conn.prepareStatement("SELECT c_code FROM course_units");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c_code_combo.addItem(rs.getString("c_code"));
            }
            if(c_code_combo.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null, "Please enter the course code");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private void getUserDetails() {
        try{
            String sql = "select * from attendance_detail where user_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, sid_tf.getText());
            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                sid_tf.setText(rs.getString("username"));
                c_code_combo.setSelectedItem(rs.getString("c_code"));
                c_hourse_tf.setText(rs.getString("c_hours"));
                lec_date_tf.setText(rs.getString("lec_date"));
                at_status_tf.setText(rs.getString("at_state"));
                c_type_tf.setText(rs.getString("c_type"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error Getting User Details. Please try again");
        }
    }

    private void databaseConnect() {
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fotdb", "root", "Dedu@1225");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Connection Failed");
        }
    }

    public JPanel getAddAttMain() {

        return AddAttMain;
    }


}
