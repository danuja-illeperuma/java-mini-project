import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.io.File;
import java.nio.file.Files;
import java.sql.*;

public class AddMedicals extends JFrame {
    private JTextField m_stu_id,m_id,s_description,sub_date,m_status,m_c_code,m_c_type;
    private JButton DELETEButton,ADDButton,CLEARButton,UPLOADIMAGEButton,UPDATEButton;
    private JLabel m_photo;
    private JTextField cut_lec_h;
    private JPanel add_panel;
    private byte[] bytePhoto;

    private Connection conn;

    public AddMedicals() {
        setTitle("Add Medicals");
        setContentPane(add_panel);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(217,240,250));

        createConnection();
        getUserData();

        DELETEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst = conn.prepareStatement("DELETE FROM medical WHERE user_id = ? ");
                    pst.setString(1, m_id.getText());
                    int remove = pst.executeUpdate();

                    if(remove>0){
                        JOptionPane.showMessageDialog(null, "Medical has been deleted successfully");
                    }else {
                        JOptionPane.showMessageDialog(null, "No deleted medical found");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error deleting medical..");
                }
            }
        });


        ADDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst = conn.prepareStatement("INSERT INTO medical (medical_id,user_id,description,sub_date,state,c_code,c_type,cut_lec_hour,medical_photo) VALUES (?,?,?,?,?,?,?,?,?)");
                    pst.setString(1, m_id.getText());
                    pst.setString(2, m_stu_id.getText());
                    pst.setString(3, s_description.getText());
                    pst.setString(4, sub_date.getText());
                    pst.setString(5, m_status.getText());
                    pst.setString(6, m_c_code.getText());
                    pst.setString(7, m_c_type.getText());
                    pst.setString(8, cut_lec_h.getText());
                    pst.setString(9, m_photo.getText());

                    int add = pst.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Medical added successfully");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error adding medical..");
                }
            }
        });
        CLEARButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m_id.setText("");
                m_stu_id.setText("");
                s_description.setText("");
                sub_date.setText("");
                m_status.setText("");
                m_c_code.setText("");
                m_c_type.setText("");
                cut_lec_h.setText("");
                m_photo.setText("no image");

            }
        });


        UPDATEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PreparedStatement pst = conn.prepareStatement("UPDATE medical SET state = ?, cut_lec_hour = ?  WHERE medical_id = ? AND c_code = ? AND user_id = ? ");
                    pst.setString(1, m_status.getText());
                    pst.setString(2, cut_lec_h.getText());
                    pst.setString(3, m_id.getText());
                    pst.setString(4, m_c_code.getText());
                    pst.setString(5, m_stu_id.getText());
                    int update = pst.executeUpdate();

                    if(update>0){
                        JOptionPane.showMessageDialog(null, "Medical updated successfully");
                    }else {
                        JOptionPane.showMessageDialog(null, "No updated medical found");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error updating medical..");
                }
            }
        });
        UPLOADIMAGEButton.addActionListener(new ActionListener() {
            @Override
           public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Select Profile Picture");
                chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));
                int option = chooser.showOpenDialog(AddMedicals.this);

                if (option == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    try{
                        bytePhoto = Files.readAllBytes(file.toPath());
                        ImageIcon image = new ImageIcon(bytePhoto);
                        Image im = image.getImage().getScaledInstance(130,166,Image.SCALE_SMOOTH);
                        m_photo.setIcon(new ImageIcon(im));
                        m_photo.setText("");

                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(AddMedicals.this, "Error loading image file");
                    }
                }
            }
        });
        m_stu_id.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(m_stu_id.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null, "Please enter Student ID");
                }
            }
        });
        m_c_code.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(m_c_code.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null, "Please enter course Code");
                }
            }
        });
        add_panel.addComponentListener(new ComponentAdapter() {
        });
    }

    private void getUserData() {
        try{
            String sql = "SELECT * FROM medical WHERE user_id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, m_id.getText());
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                m_id.setText(rs.getString("medical_id"));
                m_stu_id.setText(rs.getString("user_id"));
                s_description.setText(rs.getString("description"));
                sub_date.setText(rs.getString("sub_date"));
                m_status.setText(rs.getString("state"));
                m_c_code.setText(rs.getString("c_code"));
                m_c_type.setText(rs.getString("c_type"));
                cut_lec_h.setText(rs.getString("cut_lec_hour"));

                bytePhoto = rs.getBytes("Medical Image");
                if(bytePhoto != null){
                    ImageIcon imageIcon = new ImageIcon(bytePhoto);
                    Image img = imageIcon.getImage().getScaledInstance(130,160, Image.SCALE_SMOOTH);
                    m_photo.setIcon(new ImageIcon(img));

                }else {
                    m_photo.setText("no image");
                    m_photo.setHorizontalTextPosition(SwingConstants.CENTER);
                }

            }else{
                JOptionPane.showMessageDialog(null, "No medical found");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Getting User Details. Please try again");
            e.printStackTrace();
        }
    }

    private void createConnection(){
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tecmis", "root", "Dedu@1225");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Connection Failed");
        }
    }

    public JPanel getAdd_panel() {
        return add_panel;
    }
}

