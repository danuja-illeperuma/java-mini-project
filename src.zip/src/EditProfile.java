import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.*;

public class EditProfile extends JFrame {
    private JTextField efname,eEmailOf, eOffId,ephone,edobOf;
    private JButton uploadPhotobtn,updateButton;
    private JLabel eOfficerId,eDob,eprofile;
    private JPasswordField passwordField1;
    private JLabel ePhotoOff;
    private JPanel req;
    private JPanel editprofile;
    private byte[] ePhoto;

    private Connection con;


    public EditProfile() {
        setTitle("Edit Profile");
        setContentPane(editprofile);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(217, 240, 250));

        req.setBackground(new Color(217, 240, 250));

        createConnection();
        getUserDetails();
        uploadPhotobtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Select Photo");
                chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files" , "jpg", "jpeg", "png", "gif") );
                int returnVal = chooser.showOpenDialog(EditProfile.this);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();

                    try{
                        ePhoto = Files.readAllBytes(file.toPath());
                        ImageIcon image = new ImageIcon(ePhoto);
                        Image im = image.getImage().getScaledInstance(130,166,Image.SCALE_SMOOTH);
                        ePhotoOff.setIcon(new ImageIcon(im));
                        ePhotoOff.setText("");


                    }catch(IOException ex){
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(EditProfile.this, "Please select a valid image file" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    PreparedStatement ps = con.prepareStatement("UPDATE user SET user_name=?,email = ?,password=?,date_of_birth=?,phone=?,photo = ? WHERE user_id=?");
                    ps.setString(1,efname.getText());
                    ps.setString(2,eEmailOf.getText());
                    ps.setString(3,new String(passwordField1.getPassword()));
                    ps.setString(4,edobOf.getText());
                    ps.setString(5,ephone.getText());
                    ps.setBytes(6, ePhoto);
                    ps.setString(7,eOffId.getText());

                    int update = ps.executeUpdate();
                    if(update > 0){
                        JOptionPane.showMessageDialog(null, "Profile picture updated Successfully!");

                    }else {
                        JOptionPane.showMessageDialog(null, "Error updating profile");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(EditProfile.this, "Error updating profile"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

        public void getUserDetails(){
            try {
                PreparedStatement ps = con.prepareStatement("SELECT * FROM user where user_id=?");
                ps.setString(1,eOffId.getText());
                ResultSet rs = ps.executeQuery();

                if(rs.next()){
                    efname.setText(rs.getString("user_name"));
                    eEmailOf.setText(rs.getString("email"));
                    passwordField1.setText(rs.getString("password"));
                    edobOf.setText(rs.getString("date_of_birth"));
                    ephone.setText(rs.getString("phone"));
                    eOfficerId.setText(rs.getString("user_id"));

                    ePhoto = rs.getBytes("photo");
                    if (ePhoto != null) {
                        ImageIcon image = new ImageIcon(ePhoto);
                        Image img = image.getImage().getScaledInstance(160, 200, Image.SCALE_SMOOTH);
                        ePhotoOff.setIcon(new ImageIcon(img));
                        eprofile.setText("");
                    }
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error loading profile" + e.getMessage());
            }
        }

    private void createConnection(){
            try{
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tecmis", "root", "Dedu@1225");

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Connection Failed");
            }
        }

    public JPanel getEditprofile() {
        return editprofile;
    }
}






