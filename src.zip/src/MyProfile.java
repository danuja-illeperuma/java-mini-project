import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.sql.SQLException;

public class MyProfile extends JFrame {


    private JLabel nameLabel;
    private JLabel namevalue;
    private JLabel idLabel;
    private JLabel idValue;
    private JLabel emailLabel;
    private JLabel EmailValue;
    private JLabel addressLabel;
    private JLabel addressValue;
    private JLabel dobLabel;
    private JLabel dobvalue;
    private JLabel depLabel;
    private JLabel depValue;
    private JPanel labelPanel;
    private JPanel valuePanel;
    private JLabel myPhoto;
    private JLabel welcome;
    private JLabel welcome_name;
    private JPanel MainProfile;

    private Connection conn;

    public MyProfile() {
        setTitle("My Profile");
        setContentPane(MainProfile);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(217,240,250));

    }

    private void getUserDetails() {
        try{
            PreparedStatement pst = conn.prepareStatement("SELECT * FROM user WHERE user_id=?");
            pst.setString(1, idValue.getText());
            ResultSet rs = pst.executeQuery();

            if(rs.next()){
                String name = rs.getString("user_name");
                welcome.setText("Welcome, " + name);
                namevalue.setText(name);
                idValue.setText(rs.getString("user_id"));
                EmailValue.setText(rs.getString("email"));
                addressValue.setText(rs.getString("address"));
                dobvalue.setText(rs.getString("date_of_birth"));
                depValue.setText(rs.getString("department"));

                byte[] imageProfile = rs.getBytes("photo");
                if(imageProfile !=  null){
                    ImageIcon imageIcon = new ImageIcon(imageProfile);
                    Image img = imageIcon.getImage().getScaledInstance(130, 160, Image.SCALE_SMOOTH);
                    myPhoto.setIcon(new ImageIcon(img));


                }else {
                    myPhoto.setText("No profile image");
                    myPhoto.setHorizontalTextPosition(SwingConstants.CENTER);
                }

            }else{
                JOptionPane.showMessageDialog(null, "No profile found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Cannot get user details");
        }
    }

    private void createConnection(){
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tecmis\", \"root\", \"Dedu@1225");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Connection Failed");
        }
    }

    public JPanel getMainProfile() {
        return MainProfile;
    }
}
