import javax.swing.*;
import java.awt.*;

public class MyProfilePanel extends JPanel {

    private JLabel profilePicLabel;
    private JLabel nameValue, idValue, departmentValue, emailValue, phoneValue, dobValue;

    public MyProfilePanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // === Header ===
        JLabel header = new JLabel("My Profile");
        header.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.setForeground(new Color(40, 60, 80));
        header.setHorizontalAlignment(SwingConstants.CENTER);
        add(header, BorderLayout.NORTH);

        // === Profile Picture & Info Panel ===
        JPanel contentPanel = new JPanel(new BorderLayout(20, 0));
        contentPanel.setBackground(Color.WHITE);

        // Left: Profile picture
        profilePicLabel = new JLabel();
        profilePicLabel.setPreferredSize(new Dimension(160, 200));
        profilePicLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        profilePicLabel.setHorizontalAlignment(SwingConstants.CENTER);
        profilePicLabel.setIcon(new ImageIcon(new ImageIcon("images/profile.png")
                .getImage().getScaledInstance(160, 200, Image.SCALE_SMOOTH)));
        contentPanel.add(profilePicLabel, BorderLayout.WEST);

        // Right: Info grid
        JPanel infoPanel = new JPanel(new GridLayout(6, 2, 10, 15));
        infoPanel.setBackground(Color.WHITE);
        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font valueFont = new Font("Segoe UI", Font.PLAIN, 14);

        infoPanel.add(createLabel("Full Name:", labelFont));
        nameValue = createValue("N/A", valueFont);
        infoPanel.add(nameValue);

        idValue = createValue("N/A", valueFont);
        infoPanel.add(createLabel("Officer ID:", labelFont));
        add(idValue);

        infoPanel.add(createLabel("Department:", labelFont));
        departmentValue = createValue("N/A", valueFont);
        infoPanel.add(departmentValue);

        infoPanel.add(createLabel("Email:", labelFont));
        emailValue = createValue("N/A", valueFont);
        infoPanel.add(emailValue);

        infoPanel.add(createLabel("Phone Number:", labelFont));
        phoneValue = createValue("N/A", valueFont);
        infoPanel.add(phoneValue);

        infoPanel.add(createLabel("Date of Birth:", labelFont));
        dobValue = createValue("N/A", valueFont);
        infoPanel.add(dobValue);

        contentPanel.add(infoPanel, BorderLayout.CENTER);
        add(contentPanel, BorderLayout.CENTER);
    }

    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(new Color(50, 50, 50));
        return label;
    }

    private JLabel createValue(String text, Font font) {
        JLabel value = new JLabel(text);
        value.setFont(font);
        value.setForeground(new Color(20, 40, 70));
        return value;
    }

    // === Setter to load data ===
    public void setProfileData(String name, String id, String dept, String email, String phone, String dob, ImageIcon profileImage) {
        nameValue.setText(name);
        idValue.setText(id);
        departmentValue.setText(dept);
        emailValue.setText(email);
        phoneValue.setText(phone);
        dobValue.setText(dob);

        if (profileImage != null) {
            Image scaled = profileImage.getImage().getScaledInstance(160, 200, Image.SCALE_SMOOTH);
            profilePicLabel.setIcon(new ImageIcon(scaled));
        }
    }

    // === Test Launcher ===
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("My Profile Example");
            MyProfilePanel panel = new MyProfilePanel();
            panel.setProfileData(
                    "Eng. Janaka Silva",
                    "TO123456",
                    "ICT Department",
                    "janaka@tecmis.edu",
                    "071-1234567",
                    "1990-01-01",
                    new ImageIcon("images/profile.png")  // replace with your image path
            );
            frame.setContentPane(panel);
            frame.setSize(600, 400);
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}

