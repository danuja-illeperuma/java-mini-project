import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TechOfficer extends JFrame {
    private JPanel MainPanel;
    private JButton myProfileButton;
    private JButton editProfileButton;
    private JButton viewAttendanceButton;
    private JButton addAttendanceButton;
    private JButton viewMedicalButton;
    private JButton addMedicalButton;
    private JButton viewNoticeButton;
    private JButton viewTimetableButton;
    private JButton logOutButton;
    private JPanel btnPanal;
    private JPanel contentPanel;
    private CardLayout cardLayout;


    public TechOfficer() {
        setTitle("Tech Officer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(217, 240, 250));
        setContentPane(MainPanel);
        setVisible(true);

        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EditProfile eProfile = new EditProfile();
                contentPanel.removeAll();
                contentPanel.add(eProfile.getEditprofile());
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });
        addAttendanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddAttendance eAttendance = new AddAttendance();
                contentPanel.removeAll();
                contentPanel.add(eAttendance.getAddAttMain());
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });
        myProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MyProfile mProfile = new MyProfile();
                contentPanel.removeAll();
                contentPanel.add(mProfile.getMainProfile());
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });
        viewMedicalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ViewMedical vMedical = new ViewMedical();
                contentPanel.removeAll();
                contentPanel.add(vMedical.getMainPanel());
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });
        addMedicalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddMedicals aMedical = new AddMedicals();
                contentPanel.removeAll();
                contentPanel.add(aMedical.getAdd_panel());
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        });
    }

    public static void main(String[] args) {
        new TechOfficer();
    }


}


