import javax.swing.*;
import java.sql.*;

public class ViewAttendance {
    private JPanel viewAtten;
    private JComboBox comboBox1;
    private JTextField textField1;
    private JCheckBox theoryCheckBox;
    private JCheckBox practicalCheckBox;
    private JTable table1;

    private Connection conn;

    public ViewAttendance() {

    }

    public void HighAttendanceWithoutMedical() {
        try{
            String sql = "SELECT * FROM studentAttendancePercentage" ;
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){

            }


        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }

    public void ExactlyAttendanceWithoutMedical() {

    }
    public void createConnection() {
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3308/tecmis", "root", "Dedu@1225");


        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}


