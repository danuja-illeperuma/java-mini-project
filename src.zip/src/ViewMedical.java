import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewMedical extends JFrame {
    private JPanel Labels;
    private JPanel Values;
    private JPanel MainPanel;
    private JLabel m_idLabel,stu_idlabel,desLabel,s_dateLabel,m_statusLebal,c_codeLabel,hoursLabel,lec_dateLabel,attLabel,c_typeLabel;
    private JLabel s_DateValue,m_statusValue,c_codeValue,c_typeValue,hoursValue,mPhotoValue,mIDValue,stu_IDValue,desValue;
    private Connection con;

    public ViewMedical() {
        setTitle("View Medical");
        setContentPane(MainPanel);
        setSize(800,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MainPanel.setBackground(new Color(217,240,250));

        createConnection();
        getUserDetails();

    }

    private void getUserDetails() {
        try{
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Medical WHERE Medical_id=?");
            ps.setString(1,mIDValue.getText());
            ResultSet rs = ps.executeQuery();

            if (rs.next()){
                mIDValue.setText(rs.getString("Medical_id"));
                stu_IDValue.setText(rs.getString("user_id"));
                desValue.setText(rs.getString("description"));
                s_DateValue.setText(rs.getString("Sub_date"));
                m_statusValue.setText(rs.getString("State"));
                c_codeValue.setText(rs.getString("c_code"));
                c_typeValue.setText(rs.getString("c_type"));
                hoursValue.setText(rs.getString("cut_lec_hour"));
                mPhotoValue.setText(rs.getString("photo"));

                byte[] ImageMedical = rs.getBytes("image");
                if(ImageMedical != null){
                    ImageIcon imageIcon = new ImageIcon(ImageMedical);
                    Image im = imageIcon.getImage().getScaledInstance(130, 160, Image.SCALE_SMOOTH);
                    mPhotoValue.setIcon(new ImageIcon(im));
                    mPhotoValue.setText("");

                }else {
                    mPhotoValue.setText("No photo.");
                    mPhotoValue.setHorizontalTextPosition(JLabel.CENTER);

                }
            }else{
                JOptionPane.showMessageDialog(null, "No record found");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Can't get user details" + e.getMessage());
        }
    }

    private void createConnection(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tecmis","root","Dedu@1225");
        } catch (SQLException e){
            e.printStackTrace();
            System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, "Connection Failed");
        }
    }

    public JPanel getMainPanel() {
        return MainPanel;
    }
}
